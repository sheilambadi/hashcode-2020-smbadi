/**
 * @author Sheila Mbadi
 * 
 * Hashcode 2020 Online Qualification Round
 *
 * Book class
 * 
 */

public class Book
{
	private int score;

	public int getScore()			{ return score; }

	public void setScore(int score)	{ this.score = score; }
}
