/**
 * @author Sheila Mbadi
 * 
 * Hashcode 2020 Online Qualification Round
 *
 * Book class
 * 
 */

public class Book
{
	private int score;
	private int bookNo;

	public int getScore()			{ return score; }
	public int getBookNo()			{ return bookNo; }

	public void setScore(int score)	{ this.score = score; }
	public void setBookNo(int bookNo)	{ this.bookNo = bookNo; }
}
